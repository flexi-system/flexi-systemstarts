package com.dit.flexiSystem;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class updatePassword
 */
@WebServlet("/updatePassword")
public class updatePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updatePassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String pass1=" ",roll=" ";
		pass1=request.getParameter("pass");
		System.out.println(pass1);
		HttpSession sess=request.getSession();
		roll=(String)sess.getAttribute("rollno");
		System.out.println(roll);
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","dit","root");
				Statement st=con.createStatement();
				String sql="UPDATE student_information SET Password = '"+pass1+"' WHERE ROLL_No = '"+roll+"'";
				int a=st.executeUpdate(sql);
				System.out.println(a);
				response.sendRedirect("index.jsp");
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		
	}

}
