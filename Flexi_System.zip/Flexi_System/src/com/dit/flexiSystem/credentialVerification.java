package com.dit.flexiSystem;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class credentialVerification
 */
@WebServlet("/credentialVerification")
public class credentialVerification extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public credentialVerification() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String roll=request.getParameter("User_ID");
		String email=request.getParameter("Email_ID");
		String mobile=request.getParameter("Mno");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","dit","root");
			Statement st=con.createStatement();
			String sql="select * from student_information";
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				String roll1=rs.getString("ROLL_No");
				String email1=rs.getString("E_mail");
				String mobile1=rs.getString("Contact_No");
				if(roll.equalsIgnoreCase(roll1)&&email.equalsIgnoreCase(email1)&&mobile.equalsIgnoreCase(mobile1))
				{
					HttpSession sess=request.getSession();
					sess.setAttribute("rollno", roll);
					sess.setAttribute("email", email1);
					response.sendRedirect("otpgenerator");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
