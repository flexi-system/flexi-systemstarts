package com.dit.flexiSystem;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class MailApp
 */
@WebServlet("/MailApp")
public class MailApp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MailApp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession sess=request.getSession();
        String otp=(String) sess.getAttribute("otp");
        String email=(String) sess.getAttribute("email");
        String to = email;
        String subject = "OTP Verification Code";
        String message = "Your OTP is "+otp+" for verification of credentials valid for 2 minutes.";
        String user = "flexisystem.dit@gmail.com";
        String pass = "Flexi@system@DIT123";
        SendMail.send(to,subject, message, user, pass);
        System.out.println("OTP send successfully");
        response.sendRedirect("enter_otp.jsp");
	}

}
