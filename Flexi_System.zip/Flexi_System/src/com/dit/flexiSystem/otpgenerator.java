package com.dit.flexiSystem;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class otpgenerator
 */
@WebServlet("/otpgenerator")
public class otpgenerator extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public otpgenerator() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	        // Length of your password as I have choose 
	        // here to be 8 
	        int length = 6; 
	        String otp=geek_Password(length);
	        HttpSession sess=request.getSession();
	        sess.setAttribute("otp", otp);
	        System.out.println(otp);
	        response.sendRedirect("MailApp");
	  
	    // This our Password generating method 
	    // We have use static here, so that we not to 
	    // make any object for it 
 
	}
    static String geek_Password(int len) 
    { 
        // A strong password has Cap_chars, Lower_chars, 
        // numeric value and symbols. So we are using all of 
        // them to generate our password 
        String Capital_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
        String Small_chars = "abcdefghijklmnopqrstuvwxyz"; 
        String numbers = "0123456789"; 
                 
  
  
        String values = Capital_chars + Small_chars + 
                        numbers; 
  
        // Using random method 
        Random rndm_method = new Random(); 
  
        char[] password = new char[len]; 
  String otp="";
        for (int i = 0; i < len; i++) 
        { 
            // Use of charAt() method : to get character value 
            // Use of nextInt() as it is scanning the value as int 
            password[i] = 
              values.charAt(rndm_method.nextInt(values.length())); 
            otp+=password[i];
  
        } 
        return otp; 
    }
}
