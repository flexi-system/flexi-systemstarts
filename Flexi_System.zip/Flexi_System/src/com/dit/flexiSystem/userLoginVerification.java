package com.dit.flexiSystem;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Statement;

/**
 * Servlet implementation class userLoginVerification
 */
@WebServlet("/userLoginVerification")
public class userLoginVerification extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userLoginVerification() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String user=request.getParameter("user");
		String password=request.getParameter("password");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","dit","root");
			Statement st=con.createStatement();
			String sql="select * from student_information";
			ResultSet rs=st.executeQuery(sql);
			HttpSession sess=request.getSession();
			int k=0;
			while(rs.next())
			{
				String user1=rs.getString("ROLL_No");
				String pass1=rs.getString("Password");
				int dues=rs.getInt("Dues");
				if(user1.equalsIgnoreCase(user)&&password.equalsIgnoreCase(pass1)) {
					k=1;
					if(dues!=0) {
						response.sendRedirect("Warning.jsp");
						break;
					}
					sess.setAttribute("rollno", user1);
					response.sendRedirect("infoVerification.jsp");
					break;
				}
			}
			if(k==0)
			{
				String message="!Invalid Credentials, Enter Correct Username and Password";
				sess.setAttribute("message", message);
				response.sendRedirect("index.jsp");
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
