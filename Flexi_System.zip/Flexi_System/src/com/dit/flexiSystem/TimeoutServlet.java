package com.dit.flexiSystem;

import java.io.IOException;
import java.io.PrintWriter;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
 
@WebServlet("/timeoutServlet")
public class TimeoutServlet extends HttpServlet {
 
    private static final long serialVersionUID = 1L;
 
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        handleRequest(request, response);
    }
 
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 
        /***** Set Response Content Type *****/
        response.setContentType("text/html");
 
        /***** Print The Response *****/
        PrintWriter out = response.getWriter();
        String title = "Session Time-Out";      
        String docType = "<!DOCTYPE html>\n";
        out.println(docType 
                + "<html>\n" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>" + title + "</title></head>\n" + "<body>");
 
        /***** Post Parameters From The Request *****/
        String param1 = request.getParameter("otp");
        HttpSession sess=request.getSession();
        if (param1 != null && param1.equalsIgnoreCase((String)sess.getAttribute("otp"))) {
        	
        	response.sendRedirect("passwd_confirm.html");
        	
                  }
        else {
            out.println("<center><p id='errMsg' style='color: blue; font-size: larger; margin-left: 0px'>WARNING! Enter Correct OTP</center></p>");
            RequestDispatcher rdObj = request.getRequestDispatcher("/enter_otp.jsp");
            rdObj.include(request, response);
        }
        out.println("</body></html>");
        out.close();
    }
}